from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""
    def __init__(self, username, password):
       # Initializing MongoClient to acces databases and collections
        #self.client = MongoClient('mongodb://%s:%s@localhost:51612' % (username, password))
        self.client = MongoClient('mongodb://localhost:51612')
        self.database = self.client['AAC']
        
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data) #data should be dictionary
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
    def read(self, data):
        if data is not None:
            return self.database.animals.find(data, {"_id":False})
        else:
            raise Exception("Nothing to read because data parameter is empty")
            return False
        
    def update(self, data, change):
        if data is not None:
            return self.database.animals.update_one(data,{ "$set": change})
       
        else:
            raise Exception("Nothing to read because data parameter is empty")
            return False
        
    def delete(self, data):
        if data is not None:
            return self.database.animals.delete_one(data)
        else:
            raise Exception("Nothing to delete because data parameter is empty")
            return False